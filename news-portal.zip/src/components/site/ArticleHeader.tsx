// src/components/site/ArticleHeader.tsx
import Link from "next/link";
import Image from "next/image";
import styles from "./ArticleHeader.module.css";

/* Share buttons (client) */
import ShareIcons from "@/components/ui/SocialIcon/ShareIcons"; // ← path ঠিক করলাম

/* FontAwesome fallback user icon */
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUser as faUserSolid } from "@fortawesome/free-solid-svg-icons";

/** Utility: make slug from name */
function toSlug(s: string) {
  return s
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-");
}

/**
 * Post shape — compatible with /api/r2/post/[slug]
 */
type Post = {
  title: string;
  slug: string;
  date?: string;

  // author (any of these may exist)
  author?: { id?: number; name?: string; avatarUrl?: string; slug?: string } | null;
  authorName?: string | null;
  authorAvatarUrl?: string | null;

  // categories as CSV string: "Sports, Cricket"
  category?: string | null;

  // featured image
  image?: { src?: string; alt?: string } | null;
  imageUrl?: string | null; // (fallback key some code uses)
};

export default function ArticleHeader({
  post,
  absUrl,
  showTitle = true,
  showImage = true,
  ratio = "16/9",
}: {
  post: Post;
  /** absolute URL of this article for sharing */
  absUrl: string;
  /** optionally hide title/image if আপনি আলাদা কম্পোনেন্টে দেখাতে চান */
  showTitle?: boolean;
  showImage?: boolean;
  ratio?: "16/9" | "4/3" | "1/1";
}) {
  const authorName = post.author?.name ?? post.authorName ?? "";
  const authorSlug =
    post.author?.slug ??
    (authorName ? toSlug(authorName) : undefined) ??
    (post.author?.id ? String(post.author?.id) : undefined);
  const authorHref = authorSlug ? `/author/${authorSlug}` : undefined;
  const authorAvatar = post.author?.avatarUrl ?? post.authorAvatarUrl ?? "";

  // category may be CSV string
  const catList = (post.category || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .map((name) => ({ name, slug: toSlug(name) }));

  // featured image URL
  const imageUrl = post.image?.src || post.imageUrl || undefined;
  const imageAlt = post.image?.alt || post.title;

  return (
    <header className={styles.header}>
      {/* Title */}
      {showTitle && (
        <h1 className={styles.title}>
          {post.title}
        </h1>
      )}

      {/* Meta row: Left = Author → Categories → Date, Right = Share */}
      <div className={styles.metaRow}>
        <div className={styles.metaLeft}>
          {/* Author first */}
          {authorName ? (
            <div className={styles.authorWrap}>
              {authorHref ? (
                <Link href={authorHref} className={styles.authorLink} aria-label={authorName}>
                  <Avatar avatarUrl={authorAvatar} name={authorName} />
                  <span className={styles.authorName}>{authorName}</span>
                </Link>
              ) : (
                <span className={styles.authorLink} aria-label={authorName}>
                  <Avatar avatarUrl={authorAvatar} name={authorName} />
                  <span className={styles.authorName}>{authorName}</span>
                </span>
              )}
            </div>
          ) : null}

          {/* Categories second */}
          {!!catList.length && (
            <span className={styles.cats}>
              {catList.map((c) => (
                <Link key={c.slug} href={`/category/${c.slug}`} className={styles.cat}>
                  {c.name}
                </Link>
              ))}
            </span>
          )}

          {/* Date last */}
          {post.date && (
            <time className={styles.date} dateTime={post.date}>
              {post.date}
            </time>
          )}
        </div>

        {/* Right: Share buttons */}
        <ShareIcons className={styles.share} title={post.title} absUrl={absUrl} />
      </div>

      {/* Featured image (under meta). Keep unoptimized=true since your next.config has it */}
      {showImage && imageUrl && (
        <figure className={styles.figure}>
          <div className={styles.featuredBox} data-ratio={ratio}>
            <Image
              src={imageUrl}
              alt={imageAlt}
              fill
              className={styles.featuredImg}
              sizes="(min-width: 1024px) 900px, 100vw"
              unoptimized
              priority
            />
          </div>
          {/* Optional caption – not provided by API now */}
        </figure>
      )}
    </header>
  );
}

function Avatar({ avatarUrl, name }: { avatarUrl?: string; name: string }) {
  if (avatarUrl) {
    return (
      <Image
        src={avatarUrl}
        alt={name}
        width={28}
        height={28}
        className={styles.avatar}
        unoptimized
      />
    );
  }
  return (
    <span className={styles.avatarIcon} aria-hidden>
      <FontAwesomeIcon icon={faUserSolid} />
    </span>
  );
}
