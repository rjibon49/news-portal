// -----------------------------------------------------------------------------
// FILE: src/app/api/r2/post/[slug]/route.ts
// Single post (by slug) + extras
// - First try exact match on wp_posts.post_name
// - If not found, fallback: match LOWER(REPLACE(post_title,' ','-')) (no regex)
// - Includes featured image url and extras from wp_post_extra
// -----------------------------------------------------------------------------

import { NextResponse } from "next/server";
import { query } from "@/db/mysql";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// small helper
function logError(message: string, error?: any) {
  // keep console noise, but structured
  console.error(`[Post API] ${message}`, error ?? "");
}

type Row = {
  ID: number;
  post_title: string;
  post_name: string | null;
  post_date: string;
  post_modified: string;
  post_status: string;
  post_author: number;
  post_excerpt: string | null;
  post_content: string | null;
  author_name: string | null;
  thumbnail_id: string | null;
  categories: string | null;
  tags: string | null;

  // extras
  extra_subtitle: string | null;
  extra_highlight: string | null;
  extra_format: "standard" | "gallery" | "video" | null;
  extra_gallery_json: string | null;
  extra_video_embed: string | null;
};

async function fetchPostByPostName(slug: string) {
  return query<Row>(
    `
    SELECT
      p.ID,
      p.post_title,
      p.post_name,
      p.post_date,
      p.post_modified,
      p.post_status,
      p.post_author,
      p.post_excerpt,
      p.post_content,
      u.display_name AS author_name,

      /* featured image id */
      (SELECT pm.meta_value
         FROM wp_postmeta pm
        WHERE pm.post_id = p.ID AND pm.meta_key = '_thumbnail_id'
        LIMIT 1) AS thumbnail_id,

      /* extras */
      ex.subtitle     AS extra_subtitle,
      ex.highlight    AS extra_highlight,
      ex.format       AS extra_format,
      ex.gallery_json AS extra_gallery_json,
      ex.video_embed  AS extra_video_embed,

      /* category names */
      GROUP_CONCAT(DISTINCT CASE WHEN tt.taxonomy='category' THEN t.name END ORDER BY t.name SEPARATOR ', ') AS categories,
      /* tag names */
      GROUP_CONCAT(DISTINCT CASE WHEN tt.taxonomy='post_tag' THEN t.name END ORDER BY t.name SEPARATOR ', ') AS tags

    FROM wp_posts p
    LEFT JOIN wp_users u ON u.ID = p.post_author
    LEFT JOIN wp_term_relationships tr ON tr.object_id = p.ID
    LEFT JOIN wp_term_taxonomy tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
    LEFT JOIN wp_terms t ON t.term_id = tt.term_id
    LEFT JOIN wp_post_extra ex ON ex.post_id = p.ID
    WHERE p.post_type = 'post'
      AND p.post_status = 'publish'
      AND p.post_name = ?
    GROUP BY p.ID
    LIMIT 1
    `,
    [slug]
  );
}

async function fetchPostByTitleSlug(slug: string) {
  // Fallback: regex ছাড়াই—শুধু স্পেস -> '-' ও lowercase
  // (punctuation ম্যাচ না-ও হতে পারে, কিন্তু বেশিরভাগ কেস কাভার করবে)
  return query<Row>(
    `
    SELECT
      p.ID,
      p.post_title,
      p.post_name,
      p.post_date,
      p.post_modified,
      p.post_status,
      p.post_author,
      p.post_excerpt,
      p.post_content,
      u.display_name AS author_name,

      (SELECT pm.meta_value
         FROM wp_postmeta pm
        WHERE pm.post_id = p.ID AND pm.meta_key = '_thumbnail_id'
        LIMIT 1) AS thumbnail_id,

      ex.subtitle     AS extra_subtitle,
      ex.highlight    AS extra_highlight,
      ex.format       AS extra_format,
      ex.gallery_json AS extra_gallery_json,
      ex.video_embed  AS extra_video_embed,

      GROUP_CONCAT(DISTINCT CASE WHEN tt.taxonomy='category' THEN t.name END ORDER BY t.name SEPARATOR ', ') AS categories,
      GROUP_CONCAT(DISTINCT CASE WHEN tt.taxonomy='post_tag' THEN t.name END ORDER BY t.name SEPARATOR ', ') AS tags

    FROM wp_posts p
    LEFT JOIN wp_users u ON u.ID = p.post_author
    LEFT JOIN wp_term_relationships tr ON tr.object_id = p.ID
    LEFT JOIN wp_term_taxonomy tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
    LEFT JOIN wp_terms t ON t.term_id = tt.term_id
    LEFT JOIN wp_post_extra ex ON ex.post_id = p.ID
    WHERE p.post_type = 'post'
      AND p.post_status = 'publish'
      AND LOWER(REPLACE(p.post_title, ' ', '-')) = ?
    GROUP BY p.ID
    LIMIT 1
    `,
    [slug.toLowerCase()]
  );
}

export async function GET(
  _request: Request,
  context: { params: Promise<{ slug: string }> }
) {
  try {
    const params = await context.params;
    const slug = decodeURIComponent(params.slug || "").trim();
    logError(`Fetching post for slug: "${slug}"`);

    if (!slug) {
      return NextResponse.json({ error: "Missing slug" }, { status: 400 });
    }

    // 1) Try by post_name
    let rows = await fetchPostByPostName(slug);
    logError(`Query (post_name) returned ${rows.length} row(s)`);

    // 2) Fallback: slug computed from title (no regex)
    if (rows.length === 0) {
      rows = await fetchPostByTitleSlug(slug);
      logError(`Query (title->slug) returned ${rows.length} row(s)`);
    }

    if (rows.length === 0) {
      return NextResponse.json({ error: "Post not found" }, { status: 404 });
    }

    const row = rows[0];
    logError(`Found post: ID=${row.ID}, title="${row.post_title}", slug="${row.post_name}"`);

    // 3) Featured image URL from attachment guid
    let imageUrl: string | undefined;
    if (row.thumbnail_id) {
      try {
        const att = await query<{ guid: string }>(
          `SELECT guid FROM wp_posts WHERE ID = ? AND post_type = 'attachment' LIMIT 1`,
          [Number(row.thumbnail_id)]
        );
        imageUrl = att[0]?.guid;
      } catch (e) {
        logError("Error fetching thumbnail attachment", e);
      }
    }

    // 4) Build response (safe-parse gallery_json)
    let gallery: Array<number | { id: number; url?: string }> | null = null;
    if (row.extra_gallery_json) {
      try {
        gallery = JSON.parse(row.extra_gallery_json);
        if (!Array.isArray(gallery)) gallery = null;
      } catch {
        gallery = null;
      }
    }

    const post = {
      id: row.ID,
      slug: row.post_name || slug,
      title: row.post_title || "",
      excerpt: row.post_excerpt || "",
      contentHtml: row.post_content || "",
      date: row.post_date,
      updatedAt: row.post_modified,
      category: row.categories || null,
      author: row.author_name ? { id: row.post_author, name: row.author_name } : null,
      image: imageUrl ? { src: imageUrl, alt: row.post_title } : null,
      tags: row.tags || null,
      status: row.post_status,

      // extras
      subtitle: row.extra_subtitle || null,
      highlight: row.extra_highlight || null,
      format: (row.extra_format as "standard" | "gallery" | "video" | null) ?? "standard",
      gallery,
      videoEmbed: row.extra_video_embed || null,
    };

    return NextResponse.json({ post });
  } catch (error) {
    logError("Unexpected error", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
