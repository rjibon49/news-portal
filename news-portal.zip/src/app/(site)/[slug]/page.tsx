// src/app/(site)/[slug]/page.tsx
import type { Metadata } from "next";
import Link from "next/link";
import styles from "./page.module.css";
import ArticleHeader from "@/components/site/ArticleHeader";
import ArticleBody from "@/components/site/ArticleBody";
import { absoluteUrl } from "@/utils/apiBase";

export const dynamic = "force-dynamic";

async function fetchPost(slug: string) {
  if (!slug) return null;
  const url = await absoluteUrl(`/api/r2/post/${encodeURIComponent(slug)}`);
  const res = await fetch(url, { next: { revalidate: 0 }, cache: "no-store" });
  if (!res.ok) return null;
  const data = await res.json();
  return data?.post ?? null;
}

function toSlug(s: string) {
  return s
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-");
}

export async function generateMetadata(
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const post = await fetchPost(slug);
  if (!post) return { title: "Article not found" };
  return {
    title: post.title,
    description: post.excerpt || post.title,
    openGraph: {
      title: post.title,
      description: post.excerpt || post.title,
      images: post.image?.src ? [{ url: post.image.src, alt: post.image.alt || post.title }] : [],
      type: "article",
      url: `/${post.slug}`,
    },
  } satisfies Metadata;
}

export default async function ArticlePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = await fetchPost(slug);

  if (!post) {
    return (
      <main className={styles.wrap}>
        <p>Sorry, this article was not found.</p>
        <Link href="/">← Back to Home</Link>
      </main>
    );
  }

  // absolute URL for ShareIcons
  const abs = await absoluteUrl(`/${post.slug}`);

  const tagList: Array<{ name: string; slug: string }> =
    Array.isArray(post.tags)
      ? post.tags
      : typeof post.tags === "string"
      ? post.tags
          .split(",")
          .map((s: string) => s.trim())
          .filter(Boolean)
          .map((name: string) => ({ name, slug: toSlug(name) }))
      : [];

  return (
    <main className={styles.wrap}>
      <nav className={styles.breadcrumb} aria-label="Breadcrumb">
        <Link href="/">Home</Link>
        <span>/</span>
        <span>{post.title}</span>
      </nav>

      {/* ✅ নতুন meta অর্ডার সহ ArticleHeader (author -> categories -> date + right share) */}
      <ArticleHeader post={post} absUrl={abs} />

      <ArticleBody html={post.contentHtml} />

      {/* Footer tags → link সহ (আপনার আগের মতই) */}
      {tagList.length > 0 && (
        <div className={styles.tags} role="list">
          {tagList.map((t) => (
            <Link key={t.slug} href={`/tags/${t.slug}`} className={styles.tag} role="listitem">
              #{t.name}
            </Link>
          ))}
        </div>
      )}

      <div className={styles.back}>
        <Link href="/">← Back to Home</Link>
      </div>
    </main>
  );
}
